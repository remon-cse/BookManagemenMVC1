﻿using Microsoft.AspNetCore.Identity;

namespace BookManagementMVC.Models.IdentityModels
{
    public class ApplicationUser : IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}