﻿using System.ComponentModel.DataAnnotations;

namespace BookManagementMVC.Models.BookModels
{
    public class BookCategory
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; } = null!;

        public ICollection<Book>? Books { get; set; }
    }
}