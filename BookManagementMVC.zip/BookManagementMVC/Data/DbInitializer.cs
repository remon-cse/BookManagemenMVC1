﻿using BookManagementMVC.Models.BookModels;
using BookManagementMVC.Models.IdentityModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BookManagementMVC.Data
{
    public static class DbInitializer
    {
        public static async Task Initialize(ApplicationDbContext context, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            // Ensure database is created
            context.Database.EnsureCreated();

            // Create roles if they don't exist
            if (!await roleManager.RoleExistsAsync("Admin"))
            {
                await roleManager.CreateAsync(new IdentityRole("Admin"));
            }

            if (!await roleManager.RoleExistsAsync("User"))
            {
                await roleManager.CreateAsync(new IdentityRole("User"));
            }

            // Create admin user if doesn't exist
            if (await userManager.FindByEmailAsync("admin@bookmanagement.com") == null)
            {
                var adminUser = new ApplicationUser
                {
                    UserName = "admin@bookmanagement.com",
                    Email = "admin@bookmanagement.com",
                    FirstName = "Admin",
                    LastName = "User",
                    EmailConfirmed = true
                };

                await userManager.CreateAsync(adminUser, "Admin123!");
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }

            // Create sample regular user
            if (await userManager.FindByEmailAsync("user@bookmanagement.com") == null)
            {
                var regularUser = new ApplicationUser
                {
                    UserName = "user@bookmanagement.com",
                    Email = "user@bookmanagement.com",
                    FirstName = "Regular",
                    LastName = "User",
                    EmailConfirmed = true
                };

                await userManager.CreateAsync(regularUser, "User123!");
                await userManager.AddToRoleAsync(regularUser, "User");
            }

            // Add sample books if none exist
            if (!context.Books.Any())
            {
                var books = new List<Book>
                {
                    new Book
                    {
                        Title = "C# Programming Basics",
                        Author = "John Smith",
                        ISBN = "978-1234567890",
                        PublicationDate = new DateTime(2023, 1, 15),
                        Description = "A comprehensive guide to C# programming for beginners.",
                        Price = 29.99m,
                        CategoryId = 4, // Technology
                        CoverImagePath = "/images/csharp-basics.jpg"
                    },
                    new Book
                    {
                        Title = "ASP.NET Core MVC",
                        Author = "Jane Doe",
                        ISBN = "978-0987654321",
                        PublicationDate = new DateTime(2023, 3, 20),
                        Description = "Learn to build web applications with ASP.NET Core MVC.",
                        Price = 39.99m,
                        CategoryId = 4, // Technology
                        CoverImagePath = "/images/aspnet-core.jpg"
                    },
                    new Book
                    {
                        Title = "The Great Adventure",
                        Author = "Robert Johnson",
                        ISBN = "978-1122334455",
                        PublicationDate = new DateTime(2022, 11, 10),
                        Description = "An exciting adventure novel that takes you to mysterious places.",
                        Price = 19.99m,
                        CategoryId = 1, // Fiction
                        CoverImagePath = "/images/great-adventure.jpg"
                    }
                };

                context.Books.AddRange(books);
                await context.SaveChangesAsync();
            }
        }
    }
}