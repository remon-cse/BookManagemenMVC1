﻿using BookManagementMVC.Models.BookModels;
using BookManagementMVC.Models.IdentityModels;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BookManagementMVC.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<BookCategory> BookCategories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed data for categories
            modelBuilder.Entity<BookCategory>().HasData(
                new BookCategory { Id = 1, Name = "Fiction" },
                new BookCategory { Id = 2, Name = "Non-Fiction" },
                new BookCategory { Id = 3, Name = "Science" },
                new BookCategory { Id = 4, Name = "Technology" },
                new BookCategory { Id = 5, Name = "History" }
            );
        }
    }
}